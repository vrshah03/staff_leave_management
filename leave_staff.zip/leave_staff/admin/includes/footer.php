<div class="footer-wrap pd-20 mb-20 card-box">
				 Leave Management System developed by Group 20</span> </a>
			</div>