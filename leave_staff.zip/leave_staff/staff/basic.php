<?php
$name=$_FILES['file']['name'];
$type=$_FILES['file']['type'];
$size=$_FILES['file']['size'];
$tname=$_FILES['file']['tmp_name'];
$error=$_FILES['file']['error'];
$ex = substr(strrchr($name,'.'),1);

if($size > 50 && ($ex=='jpg' || $ex=='JPG' || $ex=='png' || $ex=='pdf' || $ex=='JPEG'))
{
   move_uploaded_file($tname,"proof/".$name);
   echo '<script>alert("Successfull")</script>';
   echo '<script type="text/javascript">';
   echo 'window.location.href = "apply_leave.php";';
   echo '</script>';

}
else
{
   echo "your file is not greater than 5mb";
}
?>