<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
</head>

<body>
<form method="post" action="basic.php" enctype="multipart/form-data">

Upload file:
<input type="file" name="file"/>
<br>
<input type="submit" name="submit" value="Upload"/>
</form>
</body>
</html>